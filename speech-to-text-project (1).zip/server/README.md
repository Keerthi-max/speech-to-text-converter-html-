# Speech-to-Text Server

1. Copy .env.example to .env and set OPENAI_API_KEY and MONGODB_URI.
2. Install dependencies:
   cd server
   npm install
3. Run server:
   npm run dev   # nodemon
   or
   npm start

Server runs on http://localhost:4000 by default.